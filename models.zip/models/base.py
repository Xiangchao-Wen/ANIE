from copy import deepcopy
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch_sparse import SparseTensor
from deeprobust.graph import utils as _utils

from abc import abstractmethod


def remove_multi_label_edges(pyg_data, injected_node_ids, train_mask):
    """
    检查非训练集节点与插入节点之间的连边，如果某个非训练集节点连接到多个不同类别的插入节点，
    则删除该非训练集节点与所有插入节点的连边，返回更新后的 pyg_data。

    Args:
        pyg_data: PyG 数据对象，包含 x, edge_index, y 等
        injected_node_ids: 插入节点的索引 (torch.Tensor)
        train_mask: 训练集掩码 (torch.Tensor)

    Returns:
        new_pyg_data: 更新后的 PyG 数据对象，包含新的 edge_index
    """
    # 克隆 pyg_data 以避免修改原始数据
    new_pyg_data = pyg_data.clone()

    # 确保数据在同一设备（假设使用 pyg_data 的设备）
    device = pyg_data.x.device
    edge_index = pyg_data.edge_index.to(device)
    labels = pyg_data.y.to(device)
    injected_node_ids = injected_node_ids.to(device)
    train_mask = train_mask.to(device)

    # 获取非训练集节点
    non_train_mask = ~train_mask
    non_train_ids = non_train_mask.nonzero(as_tuple=False).squeeze()  # 非训练集节点索引

    # 边界检查
    if non_train_ids.size(0) == 0 or injected_node_ids.size(0) == 0:
        return new_pyg_data

    # 初始化需要删除的边集合
    edges_to_remove = set()

    # 循环检查每个非训练集节点
    for non_train_id in non_train_ids:
        # 查找该非训练集节点的邻居（作为源或目标）
        src_mask = edge_index[0] == non_train_id
        dst_mask = edge_index[1] == non_train_id
        neighbors = torch.cat([
            edge_index[1, src_mask],  # non_train_id -> neighbor
            edge_index[0, dst_mask]  # neighbor -> non_train_id
        ]).unique()

        # 筛选邻居中的插入节点
        inj_neighbors = neighbors[torch.isin(neighbors, injected_node_ids)]

        # 如果没有连接到插入节点，跳过
        if inj_neighbors.size(0) == 0:
            continue

        # 检查邻居插入节点的标签
        neighbor_labels = labels[inj_neighbors]
        unique_labels = torch.unique(neighbor_labels)

        # 如果连接到多个不同类别的插入节点
        if unique_labels.size(0) > 1:
            # 删除该非训练集节点与所有插入节点的连边
            for inj_id in inj_neighbors:
                edges_to_remove.add((non_train_id.item(), inj_id.item()))
                edges_to_remove.add((inj_id.item(), non_train_id.item()))

    # 从 edge_index 中移除需要删除的边
    if edges_to_remove:
        edges_to_remove = torch.tensor(list(edges_to_remove), dtype=torch.long,
                                       device=device).t()  # (2, num_edges_to_remove)
        edge_mask = torch.ones(edge_index.size(1), dtype=torch.bool, device=device)
        for src, dst in edges_to_remove.t():
            mask = (edge_index[0] == src) & (edge_index[1] == dst)
            edge_mask[mask] = False
        updated_edge_index = edge_index[:, edge_mask]
        new_pyg_data.edge_index = updated_edge_index
    else:
        new_pyg_data.edge_index = edge_index
    # 更新 adj_t（PyG 的 SparseTensor）
    new_adj = SparseTensor.from_edge_index(
        new_pyg_data.edge_index,
        sparse_sizes=(new_pyg_data.x.size(0), new_pyg_data.x.size(0))
    ).coalesce()
    new_pyg_data.adj_t = new_adj

    return new_pyg_data

class ModelBase(nn.Module):

    def __init__(self,
                 config, pyg_data, device, logger,
                 with_relu=True, with_bias=True, with_bn=False):

        super(ModelBase, self).__init__()
        self.config = config
        self.pyg_data = pyg_data
        self.device = device
        self.logger = logger

        self.with_relu = with_relu
        self.with_bias = with_bias
        self.with_bn = with_bn

        self.x = pyg_data.x.to(self.device)
        self.edge_index = pyg_data.adj_t.to(self.device)
        self.labels = self.pyg_data.y.to(self.device)

        if 'learning_rate' in self.config:
            self.lr = self.config['learning_rate']
        if 'weight_decay' in self.config:
            self.weight_decay = self.config['weight_decay']
        if 'dropout' in self.config:
            self.dropout = self.config['dropout']


    def initialize(self):
        pass

    @abstractmethod
    def _forward(self, x, mat, weight=None):
        pass

    @abstractmethod
    def forward(self, x, mat, weight=None):
        pass

    @abstractmethod
    def get_embedding(self, x, mat, weight=None):
        pass

    def fit(self, pyg_data, adj_t=None, train_iters=None, patience=None, initialize=True, verbose=False):

        if initialize:
            self.initialize()

        if train_iters is None:
            train_iters = self.config['num_epochs']
        if patience is None:
            patience = self.config['patience']

        # self.logger.debug(f"total training epochs: {train_iters}, patience: {patience}")

        self.x = pyg_data.x.to(self.device)
        if adj_t is None:
            self.edge_index = pyg_data.adj_t.to(self.device)
        else:
            self.edge_index = adj_t.to(self.device)


        if patience < train_iters:
            self._train_with_early_stopping(train_iters, patience, verbose)
        else:
            self._train_with_val(train_iters, verbose)

    def _train_with_val(self, train_iters, verbose):
        if verbose:
            self.logger.debug('=== training gcn model ===')

        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        best_loss_val = 100
        best_acc_val = 0
        best_weight = None

        train_mask = self.pyg_data.train_mask
        val_mask = self.pyg_data.val_mask

        for i in range(train_iters):
            self.train()
            optimizer.zero_grad()
            output = self.forward(self.x, self.edge_index)
            loss_train = F.nll_loss(output[train_mask], self.labels[train_mask])
            loss_train.backward()
            optimizer.step()

            if verbose and i % 10 == 0:
                self.logger.debug(f'Epoch {i:04d}, training loss: {loss_train.item():.5f}')

            self.eval()
            output = self.forward(self.x, self.edge_index)
            loss_val = F.nll_loss(output[val_mask], self.labels[val_mask])
            acc_val = _utils.accuracy(output[val_mask], self.labels[val_mask])

            if best_loss_val > loss_val:
                best_loss_val = loss_val
                self.output = output
                best_weight = deepcopy(self.state_dict())

            if acc_val > best_acc_val:
                best_acc_val = acc_val
                self.output = output
                best_weight = deepcopy(self.state_dict())

        if verbose:
            self.logger.debug('=== picking the best model according to the performance on validation ===')
        if best_weight is not None:
            self.load_state_dict(best_weight)

    def _train_with_early_stopping(self, train_iters, patience, verbose):
        if verbose:
            self.logger.debug(f'=== training {self.__class__.__name__} model ===')

        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        early_stopping = patience
        best_loss_val = 100
        best_weight = None

        train_mask = self.pyg_data.train_mask
        val_mask = self.pyg_data.val_mask

        for i in range(train_iters):
            self.train()
            optimizer.zero_grad()
            output = self.forward(self.x, self.edge_index)
            loss_train = F.nll_loss(output[train_mask], self.labels[train_mask])
            loss_train.backward()
            optimizer.step()

            if verbose and i % 10 == 0:
                self.logger.debug(f'Epoch {i:04d}, training loss: {loss_train.item():.5f}')

            self.eval()
            output = self.forward(self.x, self.edge_index)

            loss_val = F.nll_loss(output[val_mask], self.labels[val_mask])

            if best_loss_val > loss_val:
                best_loss_val = loss_val
                self.output = output
                best_weight = deepcopy(self.state_dict())
                patience = early_stopping
            else:
                patience -= 1
            if i > early_stopping and patience <= 0:
                break

        if verbose:
             self.logger.debug(f'=== early stopping at {i:04d}, loss_val = {best_loss_val:.5f} ===')
        if best_weight is not None:
            self.load_state_dict(best_weight)

    def test(self, test_mask, verbose=True):
        self.eval()
        output = self.predict()
        loss_test = F.nll_loss(output[test_mask], self.labels[test_mask])
        acc_test = _utils.accuracy(output[test_mask], self.labels[test_mask])
        if verbose:
            self.logger.debug(f"Test set results: loss= {loss_test.item():.4f}, accuracy= {float(acc_test):.4f}")
        return float(acc_test)

    def predict(self, x=None, edge_index=None):

        self.eval()
        if x is None and edge_index is None:
            return self.forward(self.x, self.edge_index).detach()
        else:
            assert (type(edge_index) is torch.Tensor and edge_index.size(0) == 2) or (type(edge_index) is SparseTensor)
            assert type(x) is torch.Tensor
            x = x.to(self.device)
            edge_index = edge_index.to(self.device)
            return self.forward(x, edge_index).detach()

    def connect_injected_old(self, pyg_data, injected_node_ids, train_mask, k):
        """
        为每个类别的 injected 节点在非训练集节点中选出 top-k 相似节点，合并后与该类别所有 injected 节点相连，
        避免与已有邻居重复连接，返回新的 pyg_data。

        Args:
            pyg_data: PyG 数据对象，包含 x, edge_index, y 等
            injected_node_ids: 注入节点的索引 (torch.Tensor)
            train_mask: 训练集掩码 (torch.Tensor)
            k: 每个注入节点的 top-k 相似节点数量

        Returns:
            new_pyg_data: 更新后的 PyG 数据对象，包含新的 edge_index
        """
        new_pyg_data = pyg_data.clone()
        self.eval()  # 设置模型为评估模式

        # 移动数据到设备
        x = pyg_data.x.to(self.device)
        edge_index = pyg_data.edge_index.to(self.device)
        labels = pyg_data.y.to(self.device)
        injected_node_ids = injected_node_ids.to(self.device)
        train_mask = train_mask.to(self.device)

        # 获取非训练集节点
        non_train_mask = ~train_mask
        non_train_ids = non_train_mask.nonzero(as_tuple=False).squeeze()  # 非训练集节点索引

        if non_train_ids.size(0) == 0 or injected_node_ids.size(0) == 0:
            return new_pyg_data  # 如果没有非训练集节点或注入节点，直接返回

        # 计算嵌入
        with torch.no_grad():
            # embeddings = self.get_embedding(x, edge_index)  # 所有节点的嵌入
            embeddings = self.forward(x,edge_index)
            # embeddings = F.normalize(embeddings, p=2, dim=-1)  # 确保嵌入归一化
            emb_inj = embeddings[injected_node_ids]  # 注入节点的嵌入
            emb_non_train = embeddings[non_train_ids]  # 非训练集节点的嵌入

        # 获取注入节点的标签
        label_inj = labels[injected_node_ids]
        unique_labels = torch.unique(label_inj)  # 注入节点的类别列表

        # 初始化新边的列表
        new_edges = []

        # 为每个类别处理注入节点
        for label in unique_labels:
            # 筛选该类别的 injected_node_ids
            label_mask = (label_inj == label)
            label_inj_ids = injected_node_ids[label_mask]  # 该类别的注入节点
            label_emb_inj = emb_inj[label_mask]  # 该类别的注入节点嵌入

            if label_inj_ids.size(0) == 0:
                continue

            # 获取已有邻居（避免重复加边）
            existing_neighbors = set()
            for inj_id in label_inj_ids:
                # 查找 inj_id 的所有邻居（在 edge_index 中）
                neighbors = edge_index[1, edge_index[0] == inj_id].cpu().tolist()
                neighbors += edge_index[0, edge_index[1] == inj_id].cpu().tolist()  # 双向边
                existing_neighbors.update(neighbors)

            # 转换为 tensor，用于筛选
            existing_neighbors = torch.tensor(list(existing_neighbors), device=self.device)
            # 仅保留非训练集节点中不在已有邻居中的节点
            valid_non_train_mask = ~torch.isin(non_train_ids, existing_neighbors)
            valid_non_train_ids = non_train_ids[valid_non_train_mask]
            valid_emb_non_train = emb_non_train[valid_non_train_mask]

            if valid_non_train_ids.size(0) == 0:
                continue  # 如果没有有效非训练集节点，跳过

            # 计算每个注入节点的 top-k 相似节点
            topk_nodes = set()
            for inj_emb in label_emb_inj:
                inj_emb = inj_emb.unsqueeze(0)  # (1 x D)
                # 计算余弦相似度
                similarities = F.cosine_similarity(inj_emb, valid_emb_non_train, dim=-1)  # (n_valid_non_train,)
                # 选择 top-k 相似节点
                k_eff = min(k, similarities.size(0))
                topk_values, topk_indices = similarities.topk(k_eff, largest=True)
                topk_node_ids = valid_non_train_ids[topk_indices]  # 对应的节点索引
                topk_nodes.update(topk_node_ids.cpu().tolist())

            # 转换为 tensor
            topk_nodes = torch.tensor(list(topk_nodes), dtype=torch.long, device=self.device)

            # 添加边：该类别的所有 injected_node_ids 与 topk_nodes 相连
            for inj_id in label_inj_ids:
                for topk_id in topk_nodes:
                    new_edges.append([inj_id.item(), topk_id.item()])  # inj_id -> topk_id
                    new_edges.append([topk_id.item(), inj_id.item()])  # topk_id -> inj_id

        # 更新 edge_index
        if new_edges:
            new_edges = torch.tensor(new_edges, dtype=torch.long, device=self.device).t()  # (2, num_new_edges)
            updated_edge_index = torch.cat([edge_index, new_edges], dim=1)  # 合并原有边和新边
            # 去重
            updated_edge_index = torch.unique(updated_edge_index, dim=1)
            new_pyg_data.edge_index = updated_edge_index
            # 更新 adj_t（PyG 的 SparseTensor）
            new_adj = SparseTensor.from_edge_index(
                new_pyg_data.edge_index,
                sparse_sizes=(new_pyg_data.x.size(0), new_pyg_data.x.size(0))
            ).coalesce()
            new_pyg_data.adj_t = new_adj
        return new_pyg_data

    def connect_injected(self, pyg_data, injected_node_ids, train_mask, k, min_sim_threshold=0.75, merge_topk=False):
        """
        为每个类别的 injected 节点在非训练集节点中选出 top-k 相似节点，根据 merge_topk 参数选择合并或独立连接，
        避免与已有邻居重复连接，加入最小相似度阈值，返回新的 pyg_data。

        Args:
            pyg_data: PyG 数据对象，包含 x, edge_index, y 等
            injected_node_ids: 注入节点的索引 (torch.Tensor)
            train_mask: 训练集掩码 (torch.Tensor)
            k: 每个注入节点的 top-k 相似节点数量
            min_sim_threshold: 最小相似度阈值，过滤低相似度连接 (float, default=0.5)
            merge_topk: 是否合并同类别 top-k 节点 (bool, default=True)
                       - True: 合并后连接所有同类别 injected_node_ids
                       - False: 每个 injected_node_id 只连接其自身 top-k 节点

        Returns:
            new_pyg_data: 更新后的 PyG 数据对象，包含新的 edge_index
        """
        new_pyg_data = pyg_data.clone()
        self.eval()

        # 移动数据到设备
        x = pyg_data.x.to(self.device)
        edge_index = pyg_data.edge_index.to(self.device)
        labels = pyg_data.y.to(self.device)
        injected_node_ids = injected_node_ids.to(self.device)
        train_mask = train_mask.to(self.device)

        # 获取非训练集节点
        non_train_mask = ~train_mask
        non_train_ids = non_train_mask.nonzero(as_tuple=False).squeeze()
        if non_train_ids.size(0) == 0 or injected_node_ids.size(0) == 0:
            return new_pyg_data

        # 计算嵌入
        with torch.no_grad():
            embeddings = self.get_embedding(x, edge_index)
            embeddings = F.normalize(embeddings, p=2, dim=-1)  # 确保嵌入归一化
            emb_inj = embeddings[injected_node_ids]
            emb_non_train = embeddings[non_train_ids]

        # 获取注入节点的标签
        label_inj = labels[injected_node_ids]
        unique_labels = torch.unique(label_inj)
        new_edges = []

        # 为每个类别处理注入
        for label in unique_labels:
            label_mask = (label_inj == label)
            label_inj_ids = injected_node_ids[label_mask]
            label_emb_inj = emb_inj[label_mask]
            if label_inj_ids.size(0) == 0:
                continue

            if merge_topk:
                # 合并策略：合并同类别所有 injected_node_ids 的 top-k 节点
                topk_nodes = set()
                for i, inj_id in enumerate(label_inj_ids):
                    # 单独过滤该 injected_node_id 的邻居
                    neighbors = edge_index[1, edge_index[0] == inj_id].cpu().tolist()
                    neighbors += edge_index[0, edge_index[1] == inj_id].cpu().tolist()
                    neighbors = torch.tensor(list(set(neighbors)), device=self.device)

                    # 过滤非训练集节点
                    valid_non_train_mask = ~torch.isin(non_train_ids, neighbors)
                    valid_non_train_ids = non_train_ids[valid_non_train_mask]
                    valid_emb_non_train = emb_non_train[valid_non_train_mask]
                    if valid_non_train_ids.size(0) == 0:
                        continue

                    # 计算相似度
                    inj_emb = label_emb_inj[i:i + 1]  # (1 x D)
                    similarities = F.cosine_similarity(inj_emb, valid_emb_non_train, dim=-1)
                    k_eff = min(k, similarities.size(0))
                    topk_values, topk_indices = similarities.topk(k_eff, largest=True)

                    # 应用最小相似度阈值
                    valid_topk_mask = topk_values > min_sim_threshold
                    topk_node_ids = valid_non_train_ids[topk_indices[valid_topk_mask]]
                    topk_nodes.update(topk_node_ids.cpu().tolist())

                # 转换为 tensor
                topk_nodes = torch.tensor(list(topk_nodes), dtype=torch.long, device=self.device)

                # 添加边：所有 label_inj_ids 与 topk_nodes 相连
                for inj_id in label_inj_ids:
                    for topk_id in topk_nodes:
                        new_edges.append([inj_id.item(), topk_id.item()])
                        new_edges.append([topk_id.item(), inj_id.item()])
            else:
                # 独立 top-k 连接：每个 injected_node_id 只连接其自身 top-k 节点
                for i, inj_id in enumerate(label_inj_ids):
                    # 单独过滤该 injected_node_id 的邻居
                    neighbors = edge_index[1, edge_index[0] == inj_id].cpu().tolist()
                    neighbors += edge_index[0, edge_index[1] == inj_id].cpu().tolist()
                    neighbors = torch.tensor(list(set(neighbors)), device=self.device)

                    # 过滤非训练集节点
                    valid_non_train_mask = ~torch.isin(non_train_ids, neighbors)
                    valid_non_train_ids = non_train_ids[valid_non_train_mask]
                    valid_emb_non_train = emb_non_train[valid_non_train_mask]
                    if valid_non_train_ids.size(0) == 0:
                        continue

                    # 计算相似度
                    inj_emb = label_emb_inj[i:i + 1]  # (1 x D)
                    similarities = F.cosine_similarity(inj_emb, valid_emb_non_train, dim=-1)
                    k_eff = min(k, similarities.size(0))
                    topk_values, topk_indices = similarities.topk(k_eff, largest=True)

                    # 应用最小相似度阈值
                    valid_topk_mask = topk_values > min_sim_threshold
                    topk_node_ids = valid_non_train_ids[topk_indices[valid_topk_mask]]

                    # 添加边：仅连接该 inj_id 的 top-k 节点
                    for topk_id in topk_node_ids:
                        new_edges.append([inj_id.item(), topk_id.item()])
                        new_edges.append([topk_id.item(), inj_id.item()])
        # 更新 edge_index
        if new_edges:
            new_edges = torch.tensor(new_edges, dtype=torch.long, device=self.device).t()
            updated_edge_index = torch.cat([edge_index, new_edges], dim=1)
            updated_edge_index = torch.unique(updated_edge_index, dim=1)
            new_pyg_data.edge_index = updated_edge_index
            # 更新 adj_t（PyG 的 SparseTensor）
            new_adj = SparseTensor.from_edge_index(
                new_pyg_data.edge_index,
                sparse_sizes=(new_pyg_data.x.size(0), new_pyg_data.x.size(0))
            ).coalesce()
            new_pyg_data.adj_t = new_adj

        return new_pyg_data
    def fit_sim(self,
                pyg_data,
                injected_node_ids,
                k=20,
                sim_loss_weight=0.1,
                connect_n=20,
                train_iters=None,
                lr=None,
                weight_decay=None,
                verbose=False):
        # 默认参数
        train_iters = train_iters or self.config.get('num_epochs', 100)
        lr = lr or self.lr
        weight_decay = weight_decay or self.weight_decay
        best_loss_val = 100
        best_acc_val = 0
        best_weight = None

        # 移动数据到设备
        x = pyg_data.x.to(self.device)
        edge_index = pyg_data.edge_index.to(self.device)
        labels = pyg_data.y.to(self.device)
        train_mask = pyg_data.train_mask.to(self.device)
        val_mask = pyg_data.val_mask.to(self.device)
        injected_node_ids = injected_node_ids.to(self.device)

        # 优化器
        optimizer = optim.Adam(self.parameters(), lr=lr, weight_decay=weight_decay)

        # 预处理训练节点
        with torch.no_grad():
            is_train = train_mask.clone()
            is_train[injected_node_ids] = False
            train_ids = is_train.nonzero(as_tuple=False).squeeze()
            label_train = labels[train_ids]

        def compute_sim_loss(logits, injected_node_ids, train_ids, label_train, k):
            """计算相似性损失（向量化）"""
            h = logits.detach()
            # h = F.normalize(h, p=2, dim=-1)  # 确保嵌入归一化
            h_inj = h[injected_node_ids]  # M x D
            label_inj = labels[injected_node_ids]  # M

            if not h_inj.size(0) or not train_ids.size(0):
                return torch.tensor(0.0, device=self.device)

            sim_loss = 0.0
            valid_count = 0

            # 批量处理每个注入节点
            for i in range(len(injected_node_ids)):
                inj_feat = h_inj[i:i + 1]  # 1 x D
                inj_label = label_inj[i]

                # 正负样本筛选
                pos_mask = (label_train == inj_label)
                neg_mask = ~pos_mask
                pos_ids = train_ids[pos_mask]
                neg_ids = train_ids[neg_mask]

                if pos_ids.size(0) == 0 or neg_ids.size(0) == 0:
                    continue

                # 采样正负样本
                n_pos = min(k, pos_ids.size(0))
                n_neg = min(n_pos, neg_ids.size(0))
                sampled_pos = pos_ids[torch.randperm(pos_ids.size(0))[:n_pos]]
                sampled_neg = neg_ids[torch.randperm(neg_ids.size(0))[:n_neg]]
                h_pos = h[sampled_pos]  # n_pos x D
                h_neg = h[sampled_neg]  # n_neg x D

                # 批量计算相似度
                sim_pos = F.cosine_similarity(inj_feat, h_pos, dim=-1)  # (n_pos,)
                sim_neg = F.cosine_similarity(inj_feat, h_neg, dim=-1)  # (n_neg,)

                # 计算损失
                # loss_pos = F.relu(margin - sim_pos).mean()
                # loss_neg = F.relu(sim_neg + margin).mean()
                loss_pos = (1 - sim_pos).mean()  # 鼓励 sim_pos 接近 1
                loss_neg = sim_neg.abs().mean()  # 鼓励 sim_neg 接近 0

                sim_loss += (loss_pos + loss_neg)
                valid_count += 1

            return sim_loss / valid_count if valid_count > 0 else torch.tensor(0.0, device=self.device)

        # 训练循环
        for epoch in range(train_iters):
            self.train()
            optimizer.zero_grad()

            # 前向传播
            logits = self.forward(x, edge_index)
            embedding = self.forward(x, edge_index)

            # 分类损失
            loss_cls = F.nll_loss(logits[train_mask], labels[train_mask])

            # 相似性损失
            sim_loss = compute_sim_loss(embedding, injected_node_ids, train_ids, label_train, k)

            # 总损失
            loss = loss_cls + sim_loss_weight * sim_loss
            loss.backward()
            optimizer.step()

            # 每 20 个 epoch 更新 edge_index
            if (epoch + 1) % 100 == 0:
                with torch.no_grad():
                    pyg_data = self.connect_injected(pyg_data, injected_node_ids, pyg_data.train_mask, connect_n)
                    # pyg_data = remove_multi_label_edges(pyg_data, injected_node_ids, pyg_data.train_mask)
                    pyg_data = pyg_data.to(self.device)  # 确保更新后的数据在正确设备上
                    if verbose:
                        print(f"Epoch {epoch + 1}: Updated edge_index, new edge count: {pyg_data.edge_index.size(1)- edge_index.size(1)}")
                    edge_index = pyg_data.edge_index.to(self.device)

            # 日志
            if verbose and epoch % 20 == 0:
                print(f"[Epoch {epoch}] cls_loss={loss_cls.item():.4f}, sim_loss={sim_loss.item():.4f}")

            self.eval()
            output = self.forward(x, edge_index)
            loss_val = F.nll_loss(output[val_mask], self.labels[val_mask])
            acc_val = _utils.accuracy(output[val_mask], self.labels[val_mask])

            if best_loss_val > loss_val:
                best_loss_val = loss_val
                self.output = output
                best_weight = deepcopy(self.state_dict())

            if acc_val > best_acc_val:
                best_acc_val = acc_val
                self.output = output
                best_weight = deepcopy(self.state_dict())

        if verbose:
            self.logger.debug('=== picking the best model according to the performance on validation ===')
        if best_weight is not None:
            self.load_state_dict(best_weight)

        self.pyg_data = pyg_data
        return

